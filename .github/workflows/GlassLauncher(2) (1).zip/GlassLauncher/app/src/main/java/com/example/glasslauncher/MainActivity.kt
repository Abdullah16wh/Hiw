package com.example.glasslauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import com.example.glasslauncher.ui.HomeScreen

class MainActivity : ComponentActivity() {

    private var drawerOpen by mutableStateOf(false)
    private var apps by mutableStateOf<List<AppEntry>>(emptyList())
    private var pins by mutableStateOf<List<String>>(emptyList())
    private var wallpaper by mutableStateOf<ImageBitmap?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        apps = AppRepository.loadApps(this)
        pins = AppRepository.loadPins(this).ifEmpty { apps.take(4).map { it.packageName } }
        wallpaper = AppRepository.loadWallpaper(this)

        setContent {
            // System photo picker: no storage permission needed
            val picker = rememberLauncherForActivityResult(
                ActivityResultContracts.PickVisualMedia()
            ) { uri ->
                if (uri != null) wallpaper = AppRepository.saveWallpaper(this, uri) ?: wallpaper
            }

            HomeScreen(
                apps = apps,
                pins = pins,
                wallpaper = wallpaper,
                onPinsChange = {
                    pins = it
                    AppRepository.savePins(this, it)
                },
                drawerOpen = drawerOpen,
                onDrawerChange = { drawerOpen = it },
                onPickWallpaper = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
            )
        }
    }

    override fun onResume() {
        super.onResume()
        // Pick up newly installed / removed apps
        apps = AppRepository.loadApps(this)
    }

    /** Pressing Home while on the home screen closes the drawer. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) drawerOpen = false
    }
}
